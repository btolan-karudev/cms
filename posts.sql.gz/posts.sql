-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le: Mer 31 Octobre 2018 à 18:51
-- Version du serveur: 5.5.38-0ubuntu0.14.04.1
-- Version de PHP: 5.5.9-1ubuntu4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `cms`
--

-- --------------------------------------------------------

--
-- Structure de la table `posts`
--

DROP TABLE IF EXISTS `posts`;
CREATE TABLE IF NOT EXISTS `posts` (
  `post_id` int(3) NOT NULL AUTO_INCREMENT,
  `post_category_id` int(3) NOT NULL,
  `post_title` varchar(255) NOT NULL,
  `post_author` varchar(255) NOT NULL,
  `post_date` date NOT NULL,
  `post_content` text NOT NULL,
  `post_image` text NOT NULL,
  `post_tags` varchar(255) NOT NULL,
  `post_comment_count` int(11) NOT NULL,
  `post_status` varchar(255) NOT NULL DEFAULT 'draft',
  PRIMARY KEY (`post_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `posts`
--

INSERT INTO `posts` (`post_id`, `post_category_id`, `post_title`, `post_author`, `post_date`, `post_content`, `post_image`, `post_tags`, `post_comment_count`, `post_status`) VALUES
(1, 1, 'La polution sur Mars', 'Benji Codeur', '2018-08-15', 'La pollution est la dégradation d''un écosystème par l''introduction, généralement humaine, de substances ou de radiations altérant de manière plus ou moins importante le fonctionnement de cet écosystème. Par extension, le mot désigne aussi parfois les conséquences de phénomènes géologiques comme une éruption volcanique.', 'https://img.lemde.fr/2015/03/18/0/0/3500/2333/534/0/60/0/ill_4596322_1819_156058.jpg', 'java, lava, script', 0, 'draft'),
(2, 2, 'Javascript Course', 'Belinda Vauder', '2018-08-04', 'avaScript est un langage de programmation de scripts principalement employé dans les pages web interactives mais aussi pour les serveurs avec l''utilisation de Node.js. Wikipédia\r\nConçu Par : Brendan Eich\r\nDate de première version : 4 décembre 1995\r\nDernière version : 8 (Juin 2017)\r\nExtension de fichier : js\r\nNormes : ECMA-262; ISO/CEI 16262\r\nParadigme : Multi-paradigme: script, orienté objet (orienté prototype), impératif, fonctionnel', 'https://upload.wikimedia.org/wikipedia/commons/thumb/9/99/Unofficial_JavaScript_logo_2.svg/512px-Unofficial_JavaScript_logo_2.svg.png', 'js jquerry', 0, 'draft');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
